CRUD DE CLIENTES - POO + MVC

Estructura:
- cliente.py: Modelo Cliente.
- cliente_controller.py: Controlador con las operaciones CRUD.
- menu_clientes.py: Vista y menú.
- json_manager.py: Lectura y escritura del archivo JSON.
- main.py: Punto de entrada.
- data/clientes.json: Archivo donde se guardan los datos.

Para ejecutar:
1. Abrir una terminal dentro de esta carpeta.
2. Ejecutar:
   python main.py

Las cuatro colecciones de Python utilizadas:
- list
- tuple
- set
- dict
