from cliente import Cliente
from json_manager import GestorJSON


class ClienteController:
    """Controla las operaciones del CRUD de clientes."""

    def __init__(self):
        self.gestor = GestorJSON("data/clientes.json")

    def obtener_registros(self):
        return self.gestor.leer()

    def siguiente_id(self):
        registros = self.obtener_registros()

        if not registros:
            return 1

        ids = [registro["id"] for registro in registros]
        return max(ids) + 1

    def correo_repetido(self, email, id_actual=None):
        email = email.strip().lower()

        for registro in self.obtener_registros():
            if registro["email"].lower() == email:
                if registro["id"] != id_actual:
                    return True

        return False

    # CREATE
    def crear(self, datos):
        try:
            obligatorios = ("nombre", "apellido", "email")

            for campo in obligatorios:
                if not datos.get(campo, "").strip():
                    return False, f"El campo {campo} es obligatorio."

            if self.correo_repetido(datos["email"]):
                return False, "Ese correo ya está registrado."

            cliente = Cliente(
                self.siguiente_id(),
                datos["nombre"],
                datos["apellido"],
                datos["email"],
                datos.get("telefono", ""),
                datos.get("ciudad", "")
            )

            registros = self.obtener_registros()
            registros.append(cliente.convertir_diccionario())

            if self.gestor.guardar(registros):
                return True, "Cliente creado correctamente."

            return False, "No se pudo guardar el cliente."

        except ValueError as error:
            return False, str(error)

    # READ
    def listar(self):
        return [
            Cliente.desde_diccionario(registro)
            for registro in self.obtener_registros()
        ]

    def buscar_por_id(self, identificador):
        for cliente in self.listar():
            if cliente.id == identificador:
                return cliente
        return None

    # SEARCH
    def buscar(self, texto):
        texto = texto.strip().lower()

        if not texto:
            return []

        resultados = []

        for registro in self.obtener_registros():
            valores = (
                registro["nombre"],
                registro["apellido"],
                registro["email"],
                registro["telefono"],
                registro["ciudad"]
            )

            if any(texto in str(valor).lower() for valor in valores):
                resultados.append(Cliente.desde_diccionario(registro))

        return resultados

    # UPDATE
    def actualizar(self, identificador, cambios):
        cliente = self.buscar_por_id(identificador)

        if cliente is None:
            return False, "El cliente no existe."

        if not cambios:
            return False, "No se indicó ningún cambio."

        try:
            if "email" in cambios:
                if self.correo_repetido(cambios["email"], identificador):
                    return False, "Ese correo ya está registrado."

            for campo, valor in cambios.items():
                if campo not in Cliente.CAMPOS:
                    return False, f"Campo no válido: {campo}"
                setattr(cliente, campo, valor)

            registros = self.obtener_registros()

            for posicion, registro in enumerate(registros):
                if registro["id"] == identificador:
                    registros[posicion] = cliente.convertir_diccionario()
                    break

            if self.gestor.guardar(registros):
                return True, "Cliente actualizado correctamente."

            return False, "No se pudo guardar la actualización."

        except ValueError as error:
            return False, str(error)

    # DELETE
    def eliminar(self, identificador):
        registros = self.obtener_registros()

        nuevos_registros = [
            registro for registro in registros
            if registro["id"] != identificador
        ]

        if len(nuevos_registros) == len(registros):
            return False, "El cliente no existe."

        if self.gestor.guardar(nuevos_registros):
            return True, "Cliente eliminado correctamente."

        return False, "No se pudo eliminar el cliente."

    # ESTADÍSTICAS
    def estadisticas(self):
        registros = self.obtener_registros()

        # SET: evita repetir ciudades.
        ciudades = {
            registro["ciudad"]
            for registro in registros
            if registro.get("ciudad")
        }

        return {
            "total": len(registros),
            "ciudades": sorted(ciudades)
        }
