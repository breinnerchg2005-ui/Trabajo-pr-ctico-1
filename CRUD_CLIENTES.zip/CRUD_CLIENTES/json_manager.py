import json
import os


class GestorJSON:
    """Se encarga de leer y guardar la información del sistema."""

    def __init__(self, archivo):
        self.__archivo = archivo

        carpeta = os.path.dirname(archivo)
        if carpeta and not os.path.exists(carpeta):
            os.makedirs(carpeta)

    def leer(self):
        if not os.path.exists(self.__archivo):
            return []

        try:
            with open(self.__archivo, "r", encoding="utf-8") as archivo:
                datos = json.load(archivo)
                return datos if isinstance(datos, list) else []
        except (json.JSONDecodeError, OSError):
            return []

    def guardar(self, datos):
        try:
            with open(self.__archivo, "w", encoding="utf-8") as archivo:
                json.dump(datos, archivo, indent=4, ensure_ascii=False)
            return True
        except (TypeError, OSError):
            return False
