from cliente_controller import ClienteController


class MenuClientes:
    """Muestra el menú y recibe los datos del usuario."""

    def __init__(self):
        self.controlador = ClienteController()
        self.activo = True

    def pausa(self):
        input("\nPresione ENTER para continuar...")

    def mostrar_menu(self):
        print("\n" + "=" * 55)
        print("          SISTEMA DE GESTIÓN DE CLIENTES")
        print("=" * 55)
        print("1. Crear cliente")
        print("2. Ver todos los clientes")
        print("3. Buscar cliente")
        print("4. Ver cliente por ID")
        print("5. Actualizar cliente")
        print("6. Eliminar cliente")
        print("7. Estadísticas")
        print("0. Salir")
        print("=" * 55)

    def pedir_id(self):
        try:
            return int(input("Ingrese el ID: "))
        except ValueError:
            print("El ID debe ser un número entero.")
            return None

    def crear(self):
        print("\n--- CREAR CLIENTE ---")

        datos = {
            "nombre": input("Nombre: "),
            "apellido": input("Apellido: "),
            "email": input("Email: "),
            "telefono": input("Teléfono: "),
            "ciudad": input("Ciudad: ")
        }

        _, mensaje = self.controlador.crear(datos)
        print(mensaje)
        self.pausa()

    def listar(self):
        print("\n--- CLIENTES REGISTRADOS ---")

        clientes = self.controlador.listar()

        if not clientes:
            print("No hay clientes registrados.")
        else:
            print("-" * 90)
            print(f"{'ID':<5}{'NOMBRE':<25}{'EMAIL':<30}{'TELÉFONO':<15}{'CIUDAD':<15}")
            print("-" * 90)

            for cliente in clientes:
                print(
                    f"{cliente.id:<5}"
                    f"{cliente.nombre_completo:<25}"
                    f"{cliente.email:<30}"
                    f"{cliente.telefono:<15}"
                    f"{cliente.ciudad:<15}"
                )

            print("-" * 90)

        self.pausa()

    def buscar(self):
        print("\n--- BUSCAR CLIENTE ---")

        texto = input("Ingrese un dato para buscar: ")
        resultados = self.controlador.buscar(texto)

        if not resultados:
            print("No se encontraron clientes.")
        else:
            for cliente in resultados:
                print(cliente)

        self.pausa()

    def ver_por_id(self):
        print("\n--- CONSULTAR CLIENTE ---")

        identificador = self.pedir_id()

        if identificador is None:
            self.pausa()
            return

        cliente = self.controlador.buscar_por_id(identificador)

        if cliente is None:
            print("No existe un cliente con ese ID.")
        else:
            print(f"ID:       {cliente.id}")
            print(f"Nombre:   {cliente.nombre}")
            print(f"Apellido: {cliente.apellido}")
            print(f"Email:    {cliente.email}")
            print(f"Teléfono: {cliente.telefono}")
            print(f"Ciudad:   {cliente.ciudad}")

        self.pausa()

    def actualizar(self):
        print("\n--- ACTUALIZAR CLIENTE ---")

        identificador = self.pedir_id()

        if identificador is None:
            self.pausa()
            return

        cliente = self.controlador.buscar_por_id(identificador)

        if cliente is None:
            print("No existe ese cliente.")
            self.pausa()
            return

        print("Deje vacío un campo si desea conservar el valor actual.")

        cambios = {}

        campos = {
            "nombre": cliente.nombre,
            "apellido": cliente.apellido,
            "email": cliente.email,
            "telefono": cliente.telefono,
            "ciudad": cliente.ciudad
        }

        for campo, actual in campos.items():
            nuevo = input(f"{campo.capitalize()} [{actual}]: ").strip()
            if nuevo:
                cambios[campo] = nuevo

        _, mensaje = self.controlador.actualizar(
            identificador,
            cambios
        )

        print(mensaje)
        self.pausa()

    def eliminar(self):
        print("\n--- ELIMINAR CLIENTE ---")

        identificador = self.pedir_id()

        if identificador is None:
            self.pausa()
            return

        cliente = self.controlador.buscar_por_id(identificador)

        if cliente is None:
            print("No existe ese cliente.")
        else:
            print(f"Cliente: {cliente.nombre_completo}")

            respuesta = input("¿Está seguro de eliminarlo? (s/n): ").lower()

            if respuesta == "s":
                _, mensaje = self.controlador.eliminar(identificador)
                print(mensaje)
            else:
                print("Operación cancelada.")

        self.pausa()

    def estadisticas(self):
        print("\n--- ESTADÍSTICAS ---")

        datos = self.controlador.estadisticas()

        print(f"Total de clientes: {datos['total']}")

        if datos["ciudades"]:
            print("Ciudades: " + ", ".join(datos["ciudades"]))
        else:
            print("Ciudades: Ninguna")

        self.pausa()

    def ejecutar(self):
        while self.activo:
            self.mostrar_menu()
            opcion = input("Seleccione una opción: ").strip()

            if opcion == "1":
                self.crear()
            elif opcion == "2":
                self.listar()
            elif opcion == "3":
                self.buscar()
            elif opcion == "4":
                self.ver_por_id()
            elif opcion == "5":
                self.actualizar()
            elif opcion == "6":
                self.eliminar()
            elif opcion == "7":
                self.estadisticas()
            elif opcion == "0":
                print("\nPrograma finalizado.")
                self.activo = False
            else:
                print("Opción no válida.")
                self.pausa()
