class Cliente:
    """Representa a un cliente del sistema."""

    CAMPOS = ("nombre", "apellido", "email", "telefono", "ciudad")

    def __init__(self, identificador, nombre, apellido, email,
                 telefono="", ciudad=""):
        self.__id = identificador
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.telefono = telefono
        self.ciudad = ciudad

    @staticmethod
    def limpiar(valor):
        return str(valor).strip()

    @staticmethod
    def validar_email(email):
        email = str(email).strip()
        return "@" in email and "." in email.split("@")[-1]

    @property
    def id(self):
        return self.__id

    @property
    def nombre(self):
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        valor = self.limpiar(valor)
        if not valor:
            raise ValueError("El nombre es obligatorio.")
        self.__nombre = valor.title()

    @property
    def apellido(self):
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        valor = self.limpiar(valor)
        if not valor:
            raise ValueError("El apellido es obligatorio.")
        self.__apellido = valor.title()

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, valor):
        valor = self.limpiar(valor).lower()
        if not self.validar_email(valor):
            raise ValueError("El correo electrónico no es válido.")
        self.__email = valor

    @property
    def telefono(self):
        return self.__telefono

    @telefono.setter
    def telefono(self, valor):
        valor = self.limpiar(valor)
        if valor and not valor.isdigit():
            raise ValueError("El teléfono debe contener solamente números.")
        self.__telefono = valor

    @property
    def ciudad(self):
        return self.__ciudad

    @ciudad.setter
    def ciudad(self, valor):
        self.__ciudad = self.limpiar(valor).title()

    @property
    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"

    def convertir_diccionario(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "email": self.email,
            "telefono": self.telefono,
            "ciudad": self.ciudad
        }

    @classmethod
    def desde_diccionario(cls, datos):
        return cls(
            datos["id"],
            datos["nombre"],
            datos["apellido"],
            datos["email"],
            datos.get("telefono", ""),
            datos.get("ciudad", "")
        )

    def __str__(self):
        return f"{self.id} - {self.nombre_completo} - {self.email}"
