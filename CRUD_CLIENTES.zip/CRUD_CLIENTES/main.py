from menu_clientes import MenuClientes


def main():
    sistema = MenuClientes()
    sistema.ejecutar()


if __name__ == "__main__":
    main()
